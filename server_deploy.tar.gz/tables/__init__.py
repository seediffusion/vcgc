"""Table management."""

from .table import Table
from .manager import TableManager

__all__ = ["Table", "TableManager"]
