"""Ninety Nine game package."""

from .game import NinetyNineGame

__all__ = ["NinetyNineGame"]
