"""Pig dice game."""

from .game import PigGame

__all__ = ["PigGame"]
