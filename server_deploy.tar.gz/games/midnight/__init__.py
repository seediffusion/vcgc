"""1-4-24 (Midnight) - Dice game where you need a 1 and 4 to score."""

from .game import MidnightGame

__all__ = ["MidnightGame"]
