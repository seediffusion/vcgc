"""Threes dice game."""

from .game import ThreesGame

__all__ = ["ThreesGame"]
