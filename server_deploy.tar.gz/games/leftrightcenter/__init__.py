"""Left Right Center game implementation."""

from .game import LeftRightCenterGame

__all__ = ["LeftRightCenterGame"]
