"""Light Turret game."""

from .game import LightTurretGame

__all__ = ["LightTurretGame"]
