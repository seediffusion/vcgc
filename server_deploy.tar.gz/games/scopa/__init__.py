"""Scopa card game module."""

from .game import ScopaGame

__all__ = ["ScopaGame"]
