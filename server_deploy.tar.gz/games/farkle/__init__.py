"""Farkle dice game implementation."""

from .game import FarkleGame

__all__ = ["FarkleGame"]
