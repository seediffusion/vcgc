"""Tradeoff dice game."""

from .game import TradeoffGame

__all__ = ["TradeoffGame"]
