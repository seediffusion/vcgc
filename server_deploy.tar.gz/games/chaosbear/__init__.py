"""Chaos Bear game - run from the bear!"""

from .game import ChaosBearGame

__all__ = ["ChaosBearGame"]
