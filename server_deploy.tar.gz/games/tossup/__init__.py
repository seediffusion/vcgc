"""Toss Up - Push-your-luck dice game."""

from .game import TossUpGame

__all__ = ["TossUpGame"]
